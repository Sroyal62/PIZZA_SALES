-- Group the orders by date and calculate the average number of pizzas ordered per day.

select orders