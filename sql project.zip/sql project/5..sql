-- List the top 5 most ordered pizza types along with their quantities.
SELECT 
    pizza_types.name, SUM(orders_details.QUANTITY) AS QUANTITY
FROM
    pizza_types
        JOIN
    pizzas ON pizza_types.pizza_type_id = pizzas.pizza_type_id
        JOIN
    orders_details ON orders_details.PIZZA_ID = pizzas.pizza_id
GROUP BY pizza_types.name
ORDER BY QUANTITY DESC
LIMIT 5;