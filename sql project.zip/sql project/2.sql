9-- Calculate the total revenue generated from pizza sales.

SELECT 
    sum(orders_details.QUANTITY * pizzas.PRICE)
FROM
    orders_details
        JOIN
    PIZZAS ON PIZZAS.pizza_id = orders_details.PIZZA_ID