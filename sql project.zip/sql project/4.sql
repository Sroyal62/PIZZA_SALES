-- Identify the most common pizza size ordered.
select
    pizzas.size, COUNT(orders_details.ORDER_DETAILS_ID) as order_cout
FROM
    PIZZAS
        JOIN
    orders_details ON pizzas.PIZZA_ID = orders_details.PIZZA_ID
GROUP BY pizzas.size
order by order_cout desc;